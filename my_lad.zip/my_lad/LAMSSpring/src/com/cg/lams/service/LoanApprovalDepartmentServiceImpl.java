package com.cg.lams.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lams.dao.LoanApprovalDepartmentDao;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;


@Service
@Transactional
public class LoanApprovalDepartmentServiceImpl implements LoanApprovalDepartmentService {
	
	@Autowired
	LoanApprovalDepartmentDao ladDao;

	@Override
	public List<LoanProgramsOffered> getLoanProgramsOffered() {
		// TODO Auto-generated method stub
		System.out.println();
		return ladDao.getLoanProgramsOffered();
	}

	@Override
	public List<String> getLoanProgramsOfferedNames() {
		// TODO Auto-generated method stub
		return ladDao.getLoanProgramsOfferedNames();
	}

	@Override
	public List<LoanApplication> getLoanApplicationByProgram() {
		// TODO Auto-generated method stub
		return ladDao.getLoanApplicationByProgram();
	}

}
