package com.cg.lams.dao;

import java.util.List;

import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

public interface LoanApprovalDepartmentDao {
	
	
	
	List<LoanProgramsOffered> getLoanProgramsOffered();
	List<String> getLoanProgramsOfferedNames();
	List<LoanApplication> getLoanApplicationByProgram();

}
