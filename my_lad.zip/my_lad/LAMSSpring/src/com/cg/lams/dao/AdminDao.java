package com.cg.lams.dao;

import com.cg.lams.entity.LoanProgramsOffered;

public interface AdminDao {

	void addLoanProgram(LoanProgramsOffered loanProgram);

}
