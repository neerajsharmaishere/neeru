package com.cg.myspringdemo.controller;

import java.util.List;

import javax.swing.text.DefaultEditorKit.CutAction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.myspringdemo.dto.Customer;
import com.cg.myspringdemo.service.ICustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	ICustomerService service;
	
	
	public ICustomerService getService() {
		return service;
	}


	public void setService(ICustomerService service) {
		this.service = service;
	}


	@RequestMapping(value="/fetchlist",method=RequestMethod.GET)
//	public String getCustomerList(Model model){
//		
//		List<Customer> list= service.getCustomerList();
//		model.addAttribute("customerList", list);
//		return "CustomerList";
//	}
	public ModelAndView getListCustomerList(Model model){
		List<Customer> list= service.getCustomerList();
		return new ModelAndView("CustomerList","data",list);
	}
	
	@RequestMapping(value="/fetchaid", method=RequestMethod.GET)
	public String getCustomer(@ModelAttribute("alpha") Customer customer){
		return "SingleCustomer";
	}
	
	@RequestMapping(value="/success", method=RequestMethod.POST)
	public ModelAndView getaCustomer(@ModelAttribute("alpha") Customer customer){
		List<Customer> list= service.getaCustomerList(customer.getCustId());
		//System.out.println("getCustId() => "+customer.getCustId()+" <>");
		//System.out.println(list);
		return new ModelAndView("success","data",list);
	}
	
}
