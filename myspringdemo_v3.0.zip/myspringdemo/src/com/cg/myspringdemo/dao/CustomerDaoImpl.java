package com.cg.myspringdemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.myspringdemo.dto.Customer;



@Repository
public class CustomerDaoImpl implements ICustomer{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Customer> getCustomerList() {
		// TODO Auto-generated method stub
		System.out.println("DAO");
		Query query = entityManager.createQuery("FROM Customer");
		List<Customer> authorList = query.getResultList();
		System.out.println(authorList);
		return authorList;
	}

	@Override
	public List<Customer> getaCustomerList(int custId) {
		// TODO Auto-generated method stub
		System.out.println("DAO"+" "+custId+" <>");
		
		Query query = entityManager.createQuery("FROM Customer WHERE custId=:custId");
		query.setParameter("custId", custId);
		List<Customer> authorList = query.getResultList();
		System.out.println(authorList);
		
//		Customer customer = new Customer(3000,"rohit");
//		authorList.add(customer);
		return authorList;
		
		/*Customer customer = entityManager.find(Customer.class,cust);
		Customer customer2 = new Customer(3000,"rohit");
		List<Customer> custom = null;
		custom.add(customer);
		custom.add(customer2);
		return custom;
		*/
	}

}
