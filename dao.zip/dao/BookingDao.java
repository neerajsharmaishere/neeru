package com.cg.hrba.dao;

import java.util.List;

import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotels;

public interface BookingDao {
	
	long insertBooking(Booking book);
	List<Hotels> getAllHotels();
}
