package com.cg.hrba.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotels;


@Repository
public class BookingDaoImpl implements BookingDao {
	
	
	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public long insertBooking(Booking book) {
		// TODO Auto-generated method stub
		int hotelId = book.getHotelId();
		String jpql = "SELECT hotels FROM Hotels hotels where hotels.hotelId =:hotelId";
		TypedQuery<Hotels> query = em.createQuery(jpql,Hotels.class).setParameter("hotelId", hotelId);
		
		Hotels hotel = query.getSingleResult();
		int rate = hotel.getHoteRate();
		int rooms = Integer.parseInt(book.getNoOfRooms());
		int amount = rate*rooms;
		book.setAmount(amount);
		em.persist(book);
		return book.getBookingId();
	}

	@Override
	public List<Hotels> getAllHotels() {
		// TODO Auto-generated method stub
		String jpql = "SELECT hotels FROM Hotels hotels";
		TypedQuery<Hotels> query = em.createQuery(jpql,Hotels.class);
		return query.getResultList();
	}

}
