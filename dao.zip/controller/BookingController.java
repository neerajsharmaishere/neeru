package com.cg.hrba.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.hrba.entity.Booking;
import com.cg.hrba.entity.Hotels;
import com.cg.hrba.service.BookingService;

@Controller
public class BookingController {
	
	@Autowired
	BookingService bser;

	@RequestMapping(value="/home")
	public String goHome(Model model){
		List<Hotels> hlist = bser.getAllHotels();
		model.addAttribute("hlist",hlist);
		model.addAttribute("book", new Booking());
		return "bookingdetails";
		
	}
	
	@RequestMapping(value="booking")
	public String register(@ModelAttribute("book") @Valid Booking book, 
			BindingResult res, Model model){
		if(res.hasErrors()){
			List<Hotels> hlist = bser.getAllHotels();
			model.addAttribute("book",book);
			model.addAttribute("hlist",hlist);
			return "booking";
		}
		else{
			long bookid = bser.booking(book);
			model.addAttribute("bookid",bookid);
			return "bookingconfirmation";
		}
	}
}
