package com.cg.myspringdemo.service;

import java.util.List;

import com.cg.myspringdemo.dto.Customer;

public interface ICustomerService {

	public List<Customer> getCustomerList();

}
