package com.cg.lams.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="LAPSLoanProgramsOffered")
public class LoanProgramsOffered {
	
	@Id
	@Column(name="PROGRAMNAME")
	@NotEmpty(message="Please Enter Program Name")
	String programName;
	
	@Column(name="DESCRIPTION")
	@NotEmpty(message="Please Enter the Description")
	String description; 
	
	@Column(name="TYPE")
	@NotEmpty(message="Please Enter the Type")
	String type;
	
	@Column(name="durationinyears")
	@NotNull(message="Please Enter the Duration")
	int duration;
	
	@Column(name="MINLOANAMOUNT")
	@NotNull(message="Please Enter the Minimum Loan Amount")
	int minLoanAmount;
	
	@Column(name="MAXLOANAMOUNT")
	@NotNull(message="Please Enter the Maximum Loan Amount")
	int maxLoanAmount;
	
	@Column(name="RATEOFINTEREST")
	@NotNull(message="Please Enter the Rate of Interest")
	int rateOfInterest;
	
	@Column(name="PROOFS_REQUIRED")
	@NotEmpty(message="Please Enter the PROOFS_REQUIRED")
	String proofRequired;
	
	public LoanProgramsOffered(){}

	public LoanProgramsOffered(String programName, String description,
			String type, int duration, int minLoanAmount, int maxLoanAmount,
			int rateOfInterest, String proofRequired) {
		super();
		this.programName = programName;
		this.description = description;
		this.type = type;
		this.duration = duration;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.rateOfInterest = rateOfInterest;
		this.proofRequired = proofRequired;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getMinLoanAmount() {
		return minLoanAmount;
	}

	public void setMinLoanAmount(int minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}

	public int getMaxLoanAmount() {
		return maxLoanAmount;
	}

	public void setMaxLoanAmount(int maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public String getProofRequired() {
		return proofRequired;
	}

	public void setProofRequired(String proofRequired) {
		this.proofRequired = proofRequired;
	}

	@Override
	public String toString() {
		return "LoanProgramsOffered [programName=" + programName
				+ ", description=" + description + ", type=" + type
				+ ", duration=" + duration + ", minLoanAmount=" + minLoanAmount
				+ ", maxLoanAmount=" + maxLoanAmount + ", rateOfInterest="
				+ rateOfInterest + ", proofRequired=" + proofRequired + "]";
	}
	
	
	
	
}
