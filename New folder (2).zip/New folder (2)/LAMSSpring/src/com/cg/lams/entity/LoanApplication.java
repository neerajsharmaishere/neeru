package com.cg.lams.entity;



import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="lapsloanapplication")
public class LoanApplication {

				//REMOVE				
	@Id
	@Column(name="application_id")
	int applicationId;
	
	@Column(name="application_date")
	Date applicationDate;
	
	@Column(name="loan_program")
	String loanProgram;
	
	@Column(name="amountofloan")
	int amountOfLoan;
	
	@Column(name="addressofproperty")
	String addressOfProperty;
	
	@Column(name="annualfamilyincome")
	int annualFamilyIncome;
	
	@Column(name="documentproofsavailable")
	String documentProofsAvailable;
	
	@Column(name="guaranteecover")
	String guaranteeCover;
	
	@Column(name="marketvalueofguaranteecover")
	int marketValueOfGuaranteeCover;
	
	@Column(name="status")
	String status;
	
	@Column(name="dateofinterview")
	Date dateOfInterview;

	public int getapplicationId() {
		return applicationId;
	}
	public void setapplicationId(int applicationId) {
		applicationId = applicationId;
	}
	public Date getapplicationDate() {
		return applicationDate;
	}
	public void setapplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getloanProgram() {
		return loanProgram;
	}
	public void setloanProgram(String loanProgram) {
		loanProgram = loanProgram;
	}
	public int getamountOfLoan() {
		return amountOfLoan;
	}
	public void setamountOfLoan(int amountOfLoan) {
		amountOfLoan = amountOfLoan;
	}
	public String getaddressOfProperty() {
		return addressOfProperty;
	}
	public void setaddressOfProperty(String addressOfProperty) {
		addressOfProperty = addressOfProperty;
	}
	public int getannualFamilyIncome() {
		return annualFamilyIncome;
	}
	public void setannualFamilyIncome(int annualFamilyIncome) {
		annualFamilyIncome = annualFamilyIncome;
	}
	public String getdocumentProofsAvailable() {
		return documentProofsAvailable;
	}
	public void setdocumentProofsAvailable(String documentProofsAvailable) {
		documentProofsAvailable = documentProofsAvailable;
	}
	public String getguaranteeCover() {
		return guaranteeCover;
	}
	public void setguaranteeCover(String guaranteeCover) {
		guaranteeCover = guaranteeCover;
	}
	public int getmarketValueOfGuaranteeCover() {
		return marketValueOfGuaranteeCover;
	}
	public void setmarketValueOfGuaranteeCover(int marketValueOfGuaranteeCover) {
		marketValueOfGuaranteeCover = marketValueOfGuaranteeCover;
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		status = status;
	}
	public Date getdateOfInterview() {
		return dateOfInterview;
	}
	public void setdateOfInterview(Date dateOfInterview) {
		dateOfInterview = dateOfInterview;
	}
	public LoanApplication(int applicationId, Date date,
			String loanProgram, int amountOfLoan, String addressOfProperty,
			int annualFamilyIncome, String documentProofsAvailable,
			String guaranteeCover, int marketValueOfGuaranteeCover,
			String status, Date date2) {
		super();
		applicationId = applicationId;
		this.applicationDate = date;
		loanProgram = loanProgram;
		amountOfLoan = amountOfLoan;
		addressOfProperty = addressOfProperty;
		annualFamilyIncome = annualFamilyIncome;
		documentProofsAvailable = documentProofsAvailable;
		guaranteeCover = guaranteeCover;
		marketValueOfGuaranteeCover = marketValueOfGuaranteeCover;
		status = status;
		dateOfInterview = date2;
	}
	public LoanApplication() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LoanApplication [applicationId=" + applicationId
				+ ", applicationDate=" + applicationDate + ", loanProgram="
				+ loanProgram + ", amountOfLoan=" + amountOfLoan
				+ ", addressOfProperty=" + addressOfProperty
				+ ", annualFamilyIncome=" + annualFamilyIncome
				+ ", documentProofsAvailable=" + documentProofsAvailable
				+ ", guaranteeCover=" + guaranteeCover
				+ ", marketValueOfGuaranteeCover="
				+ marketValueOfGuaranteeCover + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview + "]";
	}
	
	
}
