package com.cg.lams.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lams.dao.CommonDao;
import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;

@Service
@Transactional
public class CommonServiceImpl implements CommonService {

	@Autowired
	CommonDao cdao;
	
	public CommonServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public EndUsers login(EndUsers user) throws LAMSException {
		// TODO Auto-generated method stub
		return cdao.login(user);
	}

}
