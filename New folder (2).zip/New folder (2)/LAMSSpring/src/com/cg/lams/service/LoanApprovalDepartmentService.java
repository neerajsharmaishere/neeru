package com.cg.lams.service;

import java.util.List;

import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

public interface LoanApprovalDepartmentService {
	
	List<LoanProgramsOffered> getLoanProgramsOffered();
	List<String> getLoanProgramsOfferedNames();
	List<LoanApplication> getLoanApplicationByProgram(String programName);
	LoanApplication getALoanApplication(int id);
	void setALoanApplication(LoanApplication loanApplication);
}
