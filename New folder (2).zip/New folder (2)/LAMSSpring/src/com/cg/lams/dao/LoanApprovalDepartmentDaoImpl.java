package com.cg.lams.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;


@Repository
public class LoanApprovalDepartmentDaoImpl implements LoanApprovalDepartmentDao {
	
	@PersistenceContext
	EntityManager em;

	@Override
	public List<LoanProgramsOffered> getLoanProgramsOffered() {
		// TODO Auto-generated method stub
		System.out.println("DAO layer reached");
		String jpql = "select loanPrograms from LoanProgramsOffered loanPrograms";
		TypedQuery<LoanProgramsOffered> query = em.createQuery(jpql,LoanProgramsOffered.class);
		System.out.println(query.getResultList());
		return query.getResultList();
	}

	@Override
	public List<String> getLoanProgramsOfferedNames() {
		// TODO Auto-generated method stub
		String jpql = "select loanPrograms from LoanProgramsOffered loanPrograms";
		TypedQuery<LoanProgramsOffered> query = em.createQuery(jpql,LoanProgramsOffered.class);
		
		List<LoanProgramsOffered> lpo = query.getResultList();
		List<String> lpoNames = new ArrayList<>();
		for (LoanProgramsOffered loanProgramsOffered : lpo) {
			lpoNames.add(loanProgramsOffered.getProgramName());
		}
		
		System.out.println("lponames ==> "+lpoNames);
		return lpoNames;
		
		//return query.getResultList();
		
		
	}

	@Override
	public List<LoanApplication> getLoanApplicationByProgram(String loanProgram) {
		// TODO Auto-generated method stub
		String jpql = "select loanApp from LoanApplication loanApp where loanApp.loanProgram = :loanProgram";
		TypedQuery<LoanApplication> query = em.createQuery(jpql,LoanApplication.class).setParameter("loanProgram", loanProgram);
		List<LoanApplication> loanApplication = query.getResultList();
		System.out.println("query executed successfully 101.");
		return loanApplication;
	}

	@Override
	public LoanApplication getALoanApplication(int applicationId) {
		// TODO Auto-generated method stub
		String jpql = "select loanApp from LoanApplication loanApp where loanApp.applicationId = :applicationId";
		TypedQuery<LoanApplication> query = em.createQuery(jpql,LoanApplication.class).setParameter("applicationId", applicationId);
		LoanApplication loanApplication = query.getSingleResult();
		System.out.println("query executed successfully 102.");
		return loanApplication;
	}

	@Override
	public void setALoanApplication(LoanApplication loanApplication) {
		// TODO Auto-generated method stub
		em.merge(loanApplication);
		System.out.println("merged successfully...");
	}

	
}
