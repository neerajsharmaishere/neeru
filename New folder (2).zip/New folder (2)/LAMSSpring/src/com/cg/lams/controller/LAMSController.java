package com.cg.lams.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;
import com.cg.lams.service.AdminService;
import com.cg.lams.service.CommonService;
import com.cg.lams.service.LoanApprovalDepartmentService;

@Controller
public class LAMSController {
	
	@Autowired
	CommonService cser;
	
	@Autowired
	AdminService aser;
	
	@Autowired
	LoanApprovalDepartmentService ladser;
	

	public LAMSController() {
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping("adminPage")
	public String goAdminLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "AdminLogin";
		
	}
	
	@RequestMapping("ladPage")
	public String goLADLogin(Model model){
		
		model.addAttribute("user", new EndUsers());
		return "LADLogin";
		
	}
	
	@RequestMapping("customerPage")
	public String goCustomerHome(Model model){
		
		return "CustomerHome";
		
	}
	
	@RequestMapping("adminLoginAction")
	public String adminLogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("Admin");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "AdminLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "AdminHome";
		}
	}
	
	@RequestMapping("ladLoginAction")
	public String ladlogin(@ModelAttribute("user") @Valid EndUsers user, BindingResult res,Model model) throws LAMSException{
		user.setRole("LAD");
		if(res.hasErrors()){
			model.addAttribute("user",user);
			return "LADLogin";
		}
		else
		{
			EndUsers userResult = null;			
			try {
				userResult = cser.login(user);
			} catch (LAMSException e) {
				// TODO Auto-generated catch block
				throw new LAMSException("Invalid User");
			}
			return "LADHome";
		}
	}	
	
	@ExceptionHandler(value=LAMSException.class)
	public String handleException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}

	@ExceptionHandler(value=NullPointerException.class)
	public String handleNullPointerException(Model model,Exception e) {
		
		System.out.println(e.getMessage());
		model.addAttribute("message", e.getMessage());
		return "Exception";
	}
	
	@RequestMapping("addLoanPage")
	public String goAddLoan(Model model){
		
		model.addAttribute("loanProgram", new LoanProgramsOffered());
		return "AddLoanProgram";
		
	}
	
	@RequestMapping("addLoanProgramAction")
	public String register(@ModelAttribute("loanProgram") @Valid LoanProgramsOffered loanProgram, BindingResult res,Model model){
		
		if(res.hasErrors()){
			model.addAttribute("loanProgram",loanProgram);
			return "AddLoanProgram";
		}
		else
		{
			aser.addLoanProgram(loanProgram);
			System.out.println("Swastika");
			System.out.println(loanProgram);
			//model.addAttribute("msg","Loan Program Added Successfully with name"+loanProgram.getProgramName());
			return "ADDLoanProgramSuccess";
		}
	}
	
	
	//Neeraj Sharma's code Begins
	@RequestMapping(value="viewAllLoanPage")
	public String viewLoanProgramsOffered(Model model){
		
		List<LoanProgramsOffered> loanProgramsOffered = ladser.getLoanProgramsOffered();
		model.addAttribute("loanProgramsOffered",loanProgramsOffered);
		System.out.println(loanProgramsOffered.get(0).getProgramName());
		for (LoanProgramsOffered loanProgramsOffered2 : loanProgramsOffered) {
			System.out.println("program name ==>"+loanProgramsOffered2.getProgramName());
		}
		return "LADAllProgramsList";
	}
	
	@RequestMapping(value="appByLoanProgPage")
	public String viewProgramsByProgramName(Model model){
		
		List<String> loanProgramsOfferedNames = ladser.getLoanProgramsOfferedNames();
		model.addAttribute("loanProgramsOfferedNames",loanProgramsOfferedNames);
		return "LADProgramListByProgramName";
		
	}
	
	@RequestMapping(value="viewApplicationByProgram")
	public String viewApplicationByProgram(@RequestParam("id") String programName, Model model) {
		System.out.println("id ==>"+programName);
		List<LoanApplication> loanApplication = ladser.getLoanApplicationByProgram(programName);
		model.addAttribute("loanApplication",loanApplication);
		System.out.println("loanApplication at model level ==>"+loanApplication);
		return "LADApplicationByProgram";
	}
	
	@RequestMapping(value="changeStatus")
	public String changeStatus(@RequestParam("id")String id, @RequestParam("status")String status, Model model){
	//		LoanApplication loanApplication = ladser.getALoanApplicationById()
		//System.out.println("status=>"+status+"loanapp"+loanApplication);
		System.out.println("<=== "+id+status+"=====>");
		
		return "Home";
	}
	
	
	@RequestMapping(value="setAccept")
	public String setAccept(@RequestParam("id")String id,  Model model){
	//		LoanApplication loanApplication = ladser.getALoanApplicationById()
		//System.out.println("status=>"+status+"loanapp"+loanApplication);
		System.out.println("<=== "+id+"=====>");
		int id2 = Integer.parseInt(id);
		LoanApplication loanApplication = ladser.getALoanApplication(id2);
		loanApplication.setstatus("Accept");
		ladser.setALoanApplication(loanApplication);
		return "Home";
	}
	
	@RequestMapping(value="setReject")
	public String setReject(@RequestParam("id")String id,  Model model){
	//		LoanApplication loanApplication = ladser.getALoanApplicationById()
		//System.out.println("status=>"+status+"loanapp"+loanApplication);
		System.out.println("<=== "+id+"=====>");
		int id2 = Integer.parseInt(id);
		LoanApplication loanApplication = ladser.getALoanApplication(id2);
		loanApplication.setstatus("Reject");
		ladser.setALoanApplication(loanApplication);
		return "Home";
	}
	
	@RequestMapping(value="setApprove")
	public String setApprove(@RequestParam("id")String id,  Model model){
	//		LoanApplication loanApplication = ladser.getALoanApplicationById()
		//System.out.println("status=>"+status+"loanapp"+loanApplication);
		System.out.println("<=== "+id+"=====>");
		
		int id2 = Integer.parseInt(id);
		LoanApplication loanApplication = ladser.getALoanApplication(id2);
		loanApplication.setstatus("Approve");
		ladser.setALoanApplication(loanApplication);
		return "Home";
	}
	//Neeraj Sharma's code Ends
}
