package com.cg.myspringdemo.dao;

import java.util.List;

import com.cg.myspringdemo.dto.Customer;


public interface ICustomer {

	public List<Customer> getCustomerList();

	public List<Customer> getaCustomerList(int id);

}
