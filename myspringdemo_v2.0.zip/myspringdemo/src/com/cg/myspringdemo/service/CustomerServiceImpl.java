package com.cg.myspringdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.myspringdemo.dao.ICustomer;
import com.cg.myspringdemo.dto.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	ICustomer dao;
	
	@Override
	public List<Customer> getCustomerList() {
		// TODO Auto-generated method stub
		System.out.println("SERVICE");
		return dao.getCustomerList();
	}

	@Override
	public List<Customer> getaCustomerList(int id) {
		// TODO Auto-generated method stub
		return dao.getaCustomerList(id);
	}

}
