package com.cg.awsproject.service;

import com.cg.awsproject.entity.UserNames;

public interface RegisterService {

	long register(UserNames name);

}
