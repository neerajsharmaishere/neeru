package com.cg.awsproject.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.awsproject.entity.UserNames;

@Repository
public class RegisterDAOImpl implements RegisterDAO {
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public long insertRegistration(UserNames name) {
		
		
		em.persist(name);
		return name.getName();
	}
}
