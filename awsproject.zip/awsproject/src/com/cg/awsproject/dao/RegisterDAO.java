package com.cg.awsproject.dao;

import com.cg.awsproject.entity.UserNames;

public interface RegisterDAO {

	long insertRegistration(UserNames name);

}
