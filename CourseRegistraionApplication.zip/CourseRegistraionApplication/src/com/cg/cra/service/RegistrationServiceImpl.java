package com.cg.cra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.cra.dao.RegistrationDaoImpl;
import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;

@Transactional
@Service
public class RegistrationServiceImpl implements RegistrationService {
	
	@Autowired
	RegistrationDaoImpl rdao;
	
	@Override
	public long register(Registration reg) {
		// TODO Auto-generated method stub
		return rdao.insertRegistration(reg);
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return rdao.getAllCourses();
	}

	@Override
	public Registration searchStudentById(int regId) {
		// TODO Auto-generated method stub
		return rdao.searchStudentById(regId);
	}

}
